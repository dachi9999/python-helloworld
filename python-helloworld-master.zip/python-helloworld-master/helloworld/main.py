import sys

def main(argv=None):
    if argv is None:
        argv = sys.argv

    print "Hello, world"

    return 0
